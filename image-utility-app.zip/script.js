// JPG to PDF using jsPDF
async function convertJPGtoPDF() {
  const input = document.getElementById("jpgToPdfInput");
  if (!input.files.length) return alert("कृपया एक JPG फ़ाइल चुनें");

  const file = input.files[0];
  const reader = new FileReader();
  reader.onload = async function (e) {
    const imgData = e.target.result;
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF();
    const img = new Image();
    img.onload = function () {
      const ratio = img.width / img.height;
      const width = 210; // A4 width in mm
      const height = width / ratio;
      pdf.addImage(imgData, "JPEG", 0, 10, width, height);
      pdf.save("converted.pdf");
    };
    img.src = imgData;
  };
  reader.readAsDataURL(file);
}

// Resize Image using Canvas
function resizeImage() {
  const input = document.getElementById("resizeImageInput");
  const width = parseInt(document.getElementById("width").value);
  const height = parseInt(document.getElementById("height").value);
  const result = document.getElementById("resizedResult");

  if (!input.files.length || !width || !height) {
    return alert("सभी जानकारी भरें (image, width, height)");
  }

  const file = input.files[0];
  const reader = new FileReader();
  reader.onload = function (e) {
    const img = new Image();
    img.onload = function () {
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);
      const resizedData = canvas.toDataURL("image/jpeg");

      result.innerHTML = \`<a href="\${resizedData}" download="resized.jpg">
        <img src="\${resizedData}" alt="Resized Image"/>
        <br>डाउनलोड करें
      </a>\`;
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}
